# Paris City Pack — v6

- packID: `paris`
- packVersion: `6`
- schemaVersion: `4`
- ContentNode: `162`
- Root ContentNode: `86`
- Relations: `103`
- CollectionDefinition: `9` (8 existing + 1 extended Louvre route)
- Museums: `13`
- Artwork nodes: `69`
- City Stories: `4`
- Source records: `263`
- Indexed content JSON documents: `17`

## Paris-only museum curation exceptions (explicitly approved)

- Artwork-covered museums: 6 (4 Deep + 2 Selective).
- City-wide artwork ceiling: 90 (not a target).
- Per-museum artwork ceiling: 35 (not a target).
- Louvre: 26 works; routes of 12 works (90-minute selection) and 18 works (3–4-hour extended selection).
- Musée d’Orsay: 14 works; 12-stop curated museum route. Two collection works are not currently on display and are not in the route.
- Musée Marmottan Monet: 6 selected works; selective coverage, 3 DeepText works.

These exceptions apply only to this Paris pack and do not change the Master Prompt defaults for other cities.

## Day-trip and literary destinations

- Shakespeare and Company is a Paris literary/bookshop destination.
- Palace of Versailles and Disneyland Paris are out-of-city day-trip destinations.
- Disneyland Paris is represented as one root destination with two child parks: Disneyland Park and Disney Adventure World.

## Media and audio

No images were searched, downloaded, generated, edited or replaced. Existing media is preserved. New nodes have empty media arrays. No audio was generated or changed; audio fields remain downstream-managed for `leylek_pack_flow`.
