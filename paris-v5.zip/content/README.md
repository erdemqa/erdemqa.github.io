# Paris City Pack — Content Inventory

- packID: `paris`
- packVersion: `5`
- schemaVersion: `4`
- content discovery: `content/index.json` (Model B)
- canonical content files: 15
- ContentNode: 139
- root nodes: 82
- relations: 86
- CollectionDefinition: 8
- museums: 12
- artwork nodes: 52
- city stories: 4
- source records: 240

This README is documentation only. `content/index.json` is the canonical runtime content-file declaration.
Audio assets and `audioResources` are managed downstream by `leylek_pack_flow`.
