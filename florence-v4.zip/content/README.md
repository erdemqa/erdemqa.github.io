# Florence v4 city pack

Phase 12 production-data pack for Leylek.

This version keeps the existing Uffizi content and adds:

- experience nodes across Leylek\'s six content categories
- food, cafe, dessert, market, wine-bar and nightlife POIs in the tourist core and Oltrarno
- feature relations from experiences to relevant POIs
- city routes for food, golden hour and aperitivo
- research metadata with source snapshots and editorial provenance

Ratings are point-in-time snapshots captured on 2026-10-03 and should be refreshed before each production catalog release.
