# Florence v12 city pack

Schema-v3 Florence content pack, advanced from packVersion 11 to packVersion 12.

## Data and editorial status

- `schemaVersion = 3`; packVersion is synchronized at 12 in manifest, content index and all indexed documents.
- The Uffizi curated artwork count remains 25. Ten added artworks have bilingual short and standard guide tiers; artwork deepText remains capped at 8.
- Uffizi route, room hierarchy, source records, guide tiers, city graph and IDs are retained from v10 except for the explicit venue decisions documented below.
- BEN Caffè's coordinate was restored from the prior Florence v6 pack at the user's explicit direction: latitude 43.7721622, longitude 11.2563561. The current relocated address remains Via Santa Margherita 2R; exact coordinate-to-current-address alignment has not been independently verified.
- Mercato Centrale's current rating snapshot was explicitly accepted by the user and retained unchanged: 4.4/5, 58,871 Google reviews, snapshot date 2026-10-03.
- At v11, ten new artwork media arrays were intentionally left empty pending a separate image step. In v12, previously packaged Wikimedia Commons artwork files that had no content-node references were reviewed and attached to matching artwork nodes only when their subject and per-file source/licence metadata could be verified. Old room photographs that could imply an unsupported current display location were not reused as floor-plan media. Remaining optional media gaps are allowed; no placeholder path is fabricated.
- Master Prompt audio planning estimate retained from v10: Turkish 14,688 words (113.0 minutes), English 16,009 words (123.1 minutes), city estimate max(TR, EN) = 123.1 minutes at the specified 130 WPM planning constant. Actual TTS runtime is not measured.

## Validation status

- JSON syntax / duplicate-key validation, IDs, graph relations, roots, route stops, required TR/EN guide localization, guide-tier word limits, media-path integrity, manifest sizes and SHA-256 hashes are validated.
- The supplied schema-v3 Swift Codable models can decode the manifest, index and all seven indexed documents. This is a model-level decode test, not a full Xcode/iOS application build.
- The provided app source archive contains an inconsistency between `CityPackStore.currentSchemaVersion = 2` and `supportedSchemaVersions = [3]`. The delivered app-source patch updates the constant to 3; that patch must be applied to the actual app project before an app release. Full Xcode build could not be run because `xcodebuild` is unavailable in this environment.
- Venue hours and prices remain snapshots when derived from third-party listings; source notes caution against treating volatile business data as permanent facts.

## Current verdict

`NOT PRODUCTION READY` for the full app release until the app source version constant is patched and the consuming iOS app build/integration test is run. The city-pack JSON/schema/manifest checks pass. BEN Caffè coordinate alignment to the relocated address remains a disclosed location-quality caveat, per the user's chosen reuse of the historical coordinate. New images are intentionally deferred to the separate asset step.

## Uffizi room-location refresh — 2026-10-12

- Pack version advanced to 12; schemaVersion remains 3.
- First-floor room labels were reconciled against the official October 2026 visitor map: D19 Vasari Corridor entrance, D20 Venetian Chapel, D22 Antechamber of Venus, D23 Titian — Venus of Urbino, E4 Medusa/Artemisia, E5 Bacchus.
- Current room relations for Sacrifice of Isaac and Filippo Lippi's Madonna and Child with Two Angels are intentionally withheld because the current visitor map does not confirm their precise room placement (and the map marks C6-C11 work in progress).
- Botticelli's Primavera, Birth of Venus and Madonna of the Magnificat remain grouped as guided artworks, but exact physical room IDs are withheld: published visitor map and current closure notices do not agree. They are grouped under a non-spatial thematic gallery node.
- No indoor coordinates were fabricated; all affected artworks retain null indoorX/indoorY. No official Uffizi map PDF or map artwork is bundled because no explicit permissive redistribution licence was identified.
- `maps/uffizi-*-floor-route.png` are editorial sequence diagrams, not physical plans and not to scale; they include a disclaimer and were visually checked after regeneration.
- Additional Commons artwork views are linked to the corresponding artwork nodes, with local paths and source/license metadata aligned in `content/wikimedia-commons-images.json`. Unused stale Botticelli gallery photographs and unshipped backup-only source records were removed.
- Current official sources and unresolved conflicts are recorded in `content/sources.json`.
