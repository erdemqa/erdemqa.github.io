# Florence v15 city pack

Schema-v3 Florence content pack, advanced from packVersion 14 to packVersion 15.

## Data and editorial status

- `schemaVersion = 3`; packVersion 15 is synchronized across manifest, content index and all indexed content documents.
- The Uffizi curated artwork count remains 25. Ten added artworks have bilingual short and standard guide tiers; artwork deepText remains capped at 8.
- Uffizi route, room hierarchy, source records, guide tiers, city graph and IDs are retained from v10 except for the explicit venue decisions documented below.
- BEN Caffè's coordinate was restored from the prior Florence v6 pack at the user's explicit direction: latitude 43.7721622, longitude 11.2563561. The current relocated address remains Via Santa Margherita 2R; exact coordinate-to-current-address alignment has not been independently verified.
- Mercato Centrale's current rating snapshot was explicitly accepted by the user and retained unchanged: 4.4/5, 58,871 Google reviews, snapshot date 2026-10-03.
- At v11, ten new artwork media arrays were intentionally left empty pending a separate image step. In v12, previously packaged Wikimedia Commons artwork files that had no content-node references were reviewed and attached to matching artwork nodes only when their subject and per-file source/licence metadata could be verified. Old room photographs that could imply an unsupported current display location were not reused as floor-plan media. Remaining optional media gaps are allowed; no placeholder path is fabricated.
- Master Prompt audio planning estimate retained from v10: Turkish 14,688 words (113.0 minutes), English 16,009 words (123.1 minutes), city estimate max(TR, EN) = 123.1 minutes at the specified 130 WPM planning constant. Actual TTS runtime is not measured.

## Validation status

- JSON syntax / duplicate-key validation, IDs, graph relations, roots, route stops, required TR/EN guide localization, guide-tier word limits, media-path integrity, manifest sizes and SHA-256 hashes are validated.
- The supplied schema-v3 Swift Codable models can decode the manifest, index and all seven indexed documents. This is a model-level decode test, not a full Xcode/iOS application build.
- The provided app source archive contains an inconsistency between `CityPackStore.currentSchemaVersion = 2` and `supportedSchemaVersions = [3]`. The delivered app-source patch updates the constant to 3; that patch must be applied to the actual app project before an app release. Full Xcode build could not be run because `xcodebuild` is unavailable in this environment.
- Venue hours and prices remain snapshots when derived from third-party listings; source notes caution against treating volatile business data as permanent facts.

## Current verdict

`NOT PRODUCTION READY` for the full app release until the app source version constant is patched and the consuming iOS app build/integration test is run. The city-pack JSON/schema/manifest checks pass. BEN Caffè coordinate alignment to the relocated address remains a disclosed location-quality caveat, per the user's chosen reuse of the historical coordinate. New images are intentionally deferred to the separate asset step.

## Historical Uffizi room-location notes — 2026-10-12 (superseded where noted by v15)

- Pack version advanced to 12; schemaVersion remains 3.
- First-floor room labels were reconciled against the official October 2026 visitor map: D19 Vasari Corridor entrance, D20 Venetian Chapel, D22 Antechamber of Venus, D23 Titian — Venus of Urbino, E4 Medusa/Artemisia, E5 Bacchus.
- Current room relations for Sacrifice of Isaac and Filippo Lippi's Madonna and Child with Two Angels are intentionally withheld because the current visitor map does not confirm their precise room placement (and the map marks C6-C11 work in progress).
- Botticelli's Primavera, Birth of Venus and Madonna of the Magnificat remain grouped as guided artworks, but exact physical room IDs are withheld: published visitor map and current closure notices do not agree. They are grouped under a non-spatial thematic gallery node.
- No indoor coordinates were fabricated; all affected artworks retain null indoorX/indoorY. No official Uffizi map PDF or map artwork is bundled because no explicit permissive redistribution licence was identified.
- `maps/uffizi-*-floor-route.png` are editorial sequence diagrams, not physical plans and not to scale; they include a disclaimer and were visually checked after regeneration.
- Additional Commons artwork views are linked to the corresponding artwork nodes, with local paths and source/license metadata aligned in `content/wikimedia-commons-images.json`. Unused stale Botticelli gallery photographs and unshipped backup-only source records were removed.
- Current official sources and unresolved conflicts are recorded in `content/sources.json`.


## Editorial priority values (v14)

- `must_see`: core city icons and essential Uffizi artworks.
- `highly_recommended`: high-value landmarks, experiences, venues and important artworks.
- `recommended`: useful selected recommendations beyond the core must-see layer.
- `local_gem`: distinctive local discoveries; displayed in the app as “Hidden Gem”.
- `optional`: structural floor/room nodes or supporting nodes that should not show an editorial badge.

Every content node in the indexed content files has an explicit `priority` value. Full per-node assignment list is delivered separately from the production ZIP. The assignments are editorial recommendations based on the current pack and master-prompt criteria; venue ratings/opening status are not newly verified in this update.

Priority count: `must_see`=13, `highly_recommended`=37, `recommended`=15, `local_gem`=6, `optional`=21.


## Uffizi room-code and floor-plan update — 2026-10-20 (v15)

- Added `media/images/uffizi-schematic-floor-plan.png` from the user-provided Leylek schematic and linked it as a museum image on `florence.uffizi`. The image is a static, not-to-scale schematic; it is not the official museum visitor map.
- All 25 curated Uffizi artwork nodes now have `spatialContext.floorID`, `spatialContext.roomID`, and matching `contains` / `locatedIn` relationships to a room node. Museum-route stops reference the same artwork nodes, so both the 12-stop 90-minute route and the 25-artwork extended route inherit the room-code data.
- Added room records C6, A11 and A12, which were missing from the pack. Updated room display names to include official room codes. No `indoorX` / `indoorY` coordinates were fabricated.
- Important code-system limitation: the schematic graphic labels spaces `1–45` and circulation zones `A–I`. Those labels have not been verified as a one-to-one crosswalk to official catalogue room codes such as `A35`, `D23`, `E4`, and `C6`. The image is therefore included as a static schematic reference only; it must not be used for placing interactive artwork pins until that crosswalk is verified.
- Room-code choices for recently rearranged first-floor works use the October 2026 visitor map when it conflicts with older online catalogue room codes: Judith uses E4 (catalogue page D29), Bacchus uses E5 (catalogue page D32), and Venus of Urbino uses D23 (catalogue page D22). These conflicts are documented in `content/sources.json`; check live notices before visits. Sacrifice of Isaac uses E4 from the current official catalogue page; Filippo Lippi’s Madonna and Child with Two Angels uses C6 from the current catalogue page. Botticelli’s Spring is A11; Birth of Venus and Madonna of the Magnificat are A12 according to current catalogue pages.
- The official Uffizi notice checked 2026-10-20 lists A9, A17/A21 and A40/A42 on the second floor and C7/C12, D3 and D9/D11 on the first floor as work-in-progress rooms; works normally in A40/A42 can be viewed in C9/C10. This status is dynamic.

### Artwork-to-room verification list

| Official room code | Artwork nodes in this pack |
|---|---|
| A4 | Cimabue — Santa Trinita Maestà; Giotto — Ognissanti Maestà |
| A5 | Simone Martini — Annunciation Altarpiece |
| A7 | Gentile da Fabriano — Adoration of the Magi; Lorenzo Monaco — Coronation of the Virgin |
| A8 | Paolo Uccello — The Battle of San Romano |
| A11 | Botticelli — Spring (Primavera) |
| A12 | Botticelli — Birth of Venus; Madonna of the Magnificat |
| A13 | The Portinari Triptych |
| A20 | Dürer — Adoration of the Magi |
| A25 | Piero della Francesca — The Duke and Duchess of Urbino |
| A35 | Leonardo — Annunciation; Leonardo — Adoration of the Magi; Verrocchio/Leonardo — Baptism of Christ |
| A38 | Michelangelo — Doni Tondo; Raphael — Madonna of the Goldfinch |
| C6 | Filippo Lippi — Madonna and Child with Two Angels |
| D15 | Bronzino — Portrait of Eleonora di Toledo with her son Giovanni |
| D22 | Titian — Flora |
| D23* | Titian — Venus of Urbino |
| E4* | Artemisia — Judith Beheading Holofernes; Caravaggio — Medusa; Caravaggio — Sacrifice of Isaac |
| E5* | Caravaggio — Bacchus |

`*` For E4, E5 and D23, current visitor-map labels are used for navigation when they differ from older artwork-catalogue pages; see `content/sources.json`.

### Route room-code coverage

- `florence.uffizi-90min`: 12 artwork stops; all 12 now resolve to a room code through their artwork records.
- `florence.uffizi-complete-3h`: 25 artwork stops; all 25 now resolve to a room code through their artwork records. Its stop order was normalized to the verified room-code sequence.
- City routes that include the Uffizi as a whole-museum stop do not imply a particular artwork room.

## v15 validation notes

- Updated manifest file list, byte sizes and SHA-256 hashes for all packaged files.
- JSON parsing passed for all pack JSON files; artwork IDs, route stop references, room IDs, room relations and media resource paths were checked.
- This is a city-pack data validation, not an Xcode build or an in-app UI/integration test. Indoor artwork coordinates remain null by design.
