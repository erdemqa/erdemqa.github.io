# Florence v19 city-pack upgrade — PHASE 2 working checkpoint

Schema-v4 working tree advanced from packVersion 18 to packVersion 19. This is an intermediate phased-upgrade checkpoint, not final production approval.

## City detail profile

- Revised the localized city overview and kept six concise city quick facts in Turkish and English in `content/city/florence.json`. The Italian city-profile values were removed because the supplied bundled catalog has no Florence entry and only configures Turkish/English for its current city entry; the production remote catalog URL is present in source code but its live content could not be verified in this environment, so Italian support was not assumed.
- Quick facts cover region, river, Renaissance identity, UNESCO inscription year, associated artists and ancient origins.
- City-level references include UNESCO World Heritage Centre, Italia.it, Visit Tuscany and Opera del Duomo.
- The new fields are additive optional metadata on the `city` object; existing content graph, audio resources, Uffizi floor plans and routes are retained.

## Data and editorial status

- `schemaVersion = 4`; packVersion 17 is synchronized across manifest, content index and all indexed content documents.
- The Uffizi curated artwork count remains 25. Ten added artworks have bilingual short and standard guide tiers; artwork deepText remains capped at 8.
- Uffizi route, room hierarchy, source records, guide tiers, city graph and IDs are retained from v10 except for the explicit venue decisions documented below.
- BEN Caffè's coordinate was restored from the prior Florence v6 pack at the user's explicit direction: latitude 43.7721622, longitude 11.2563561. The current relocated address remains Via Santa Margherita 2R; exact coordinate-to-current-address alignment has not been independently verified.
- Mercato Centrale's current rating snapshot was explicitly accepted by the user and retained unchanged: 4.4/5, 58,871 Google reviews, snapshot date 2026-10-03.
- At v11, ten new artwork media arrays were intentionally left empty pending a separate image step. In v12, previously packaged Wikimedia Commons artwork files that had no content-node references were reviewed and attached to matching artwork nodes only when their subject and per-file source/licence metadata could be verified. Old room photographs that could imply an unsupported current display location were not reused as floor-plan media. Remaining optional media gaps are allowed; no placeholder path is fabricated.
- Master Prompt audio planning estimate retained from v10: Turkish 14,688 words (113.0 minutes), English 16,009 words (123.1 minutes), city estimate max(TR, EN) = 123.1 minutes at the specified 130 WPM planning constant. Actual TTS runtime is not measured.

## Validation status

- JSON syntax / duplicate-key validation, IDs, graph relations, roots, route stops, required TR/EN guide localization, guide-tier word limits, media-path integrity, manifest sizes and SHA-256 hashes are validated.
- The app-source patch adds optional Codable support for city profile fields and renders the localized description, quick facts and city-level source links. JSON/model/static checks passed; a full Xcode/iOS Simulator build still must be run in the developer environment.
- Venue hours and prices remain snapshots when derived from third-party listings; source notes caution against treating volatile business data as permanent facts.

## Current verdict

`CONTENT VALIDATION PASSED WITH WARNINGS`: schema, graph, audio references, city profile and manifest are consistent. 20 placeholder-image warnings remain. Apply the app patch and run an Xcode build/Simulator integration check before treating the feature as fully verified. BEN Caffè coordinate alignment to the relocated address remains a disclosed location-quality caveat. New images are intentionally deferred to the separate asset step.

## Historical Uffizi room-location notes — 2026-10-12 (superseded where noted by v15)

- Pack version advanced to 12; schemaVersion remains 3.
- First-floor room labels were reconciled against the official October 2026 visitor map: D19 Vasari Corridor entrance, D20 Venetian Chapel, D22 Antechamber of Venus, D23 Titian — Venus of Urbino, E4 Medusa/Artemisia, E5 Bacchus.
- Current room relations for Sacrifice of Isaac and Filippo Lippi's Madonna and Child with Two Angels are intentionally withheld because the current visitor map does not confirm their precise room placement (and the map marks C6-C11 work in progress).
- Botticelli's Primavera, Birth of Venus and Madonna of the Magnificat remain grouped as guided artworks, but exact physical room IDs are withheld: published visitor map and current closure notices do not agree. They are grouped under a non-spatial thematic gallery node.
- No indoor coordinates were fabricated; all affected artworks retain null indoorX/indoorY. No official Uffizi map PDF or map artwork is bundled because no explicit permissive redistribution licence was identified.
- `maps/uffizi-*-floor-route.png` are editorial sequence diagrams, not physical plans and not to scale; they include a disclaimer and were visually checked after regeneration.
- Additional Commons artwork views are linked to the corresponding artwork nodes, with local paths and source/license metadata aligned in `content/wikimedia-commons-images.json`. Unused stale Botticelli gallery photographs and unshipped backup-only source records were removed.
- Current official sources and unresolved conflicts are recorded in `content/sources.json`.


## Editorial priority values (v14)

- `must_see`: core city icons and essential Uffizi artworks.
- `highly_recommended`: high-value landmarks, experiences, venues and important artworks.
- `recommended`: useful selected recommendations beyond the core must-see layer.
- `local_gem`: distinctive local discoveries; displayed in the app as “Hidden Gem”.
- `optional`: structural floor/room nodes or supporting nodes that should not show an editorial badge.

Every content node in the indexed content files has an explicit `priority` value. Full per-node assignment list is delivered separately from the production ZIP. The assignments are editorial recommendations based on the current pack and master-prompt criteria; venue ratings/opening status are not newly verified in this update.

Priority count: `must_see`=13, `highly_recommended`=37, `recommended`=15, `local_gem`=6, `optional`=21.


## Uffizi room-code and floor-plan update — 2026-10-20 (v15)

- Added `media/images/uffizi-schematic-floor-plan.png` from the user-provided Leylek schematic and linked it as a museum image on `florence.uffizi`. The image is a static, not-to-scale schematic; it is not the official museum visitor map.
- All 25 curated Uffizi artwork nodes now have `spatialContext.floorID`, `spatialContext.roomID`, and matching `contains` / `locatedIn` relationships to a room node. Museum-route stops reference the same artwork nodes, so both the 12-stop 90-minute route and the 25-artwork extended route inherit the room-code data.
- Added room records C6, A11 and A12, which were missing from the pack. Updated room display names to include official room codes. No `indoorX` / `indoorY` coordinates were fabricated.
- Important code-system limitation: the schematic graphic labels spaces `1–45` and circulation zones `A–I`. Those labels have not been verified as a one-to-one crosswalk to official catalogue room codes such as `A35`, `D23`, `E4`, and `C6`. The image is therefore included as a static schematic reference only; it must not be used for placing interactive artwork pins until that crosswalk is verified.
- Room-code choices for recently rearranged first-floor works use the October 2026 visitor map when it conflicts with older online catalogue room codes: Judith uses E4 (catalogue page D29), Bacchus uses E5 (catalogue page D32), and Venus of Urbino uses D23 (catalogue page D22). These conflicts are documented in `content/sources.json`; check live notices before visits. Sacrifice of Isaac uses E4 from the current official catalogue page; Filippo Lippi’s Madonna and Child with Two Angels uses C6 from the current catalogue page. Botticelli’s Spring is A11; Birth of Venus and Madonna of the Magnificat are A12 according to current catalogue pages.
- The official Uffizi notice checked 2026-10-20 lists A9, A17/A21 and A40/A42 on the second floor and C7/C12, D3 and D9/D11 on the first floor as work-in-progress rooms; works normally in A40/A42 can be viewed in C9/C10. This status is dynamic.

### Artwork-to-room verification list

| Official room code | Artwork nodes in this pack |
|---|---|
| A4 | Cimabue — Santa Trinita Maestà; Giotto — Ognissanti Maestà |
| A5 | Simone Martini — Annunciation Altarpiece |
| A7 | Gentile da Fabriano — Adoration of the Magi; Lorenzo Monaco — Coronation of the Virgin |
| A8 | Paolo Uccello — The Battle of San Romano |
| A11 | Botticelli — Spring (Primavera) |
| A12 | Botticelli — Birth of Venus; Madonna of the Magnificat |
| A13 | The Portinari Triptych |
| A20 | Dürer — Adoration of the Magi |
| A25 | Piero della Francesca — The Duke and Duchess of Urbino |
| A35 | Leonardo — Annunciation; Leonardo — Adoration of the Magi; Verrocchio/Leonardo — Baptism of Christ |
| A38 | Michelangelo — Doni Tondo; Raphael — Madonna of the Goldfinch |
| C6 | Filippo Lippi — Madonna and Child with Two Angels |
| D15 | Bronzino — Portrait of Eleonora di Toledo with her son Giovanni |
| D22 | Titian — Flora |
| D23* | Titian — Venus of Urbino |
| E4* | Artemisia — Judith Beheading Holofernes; Caravaggio — Medusa; Caravaggio — Sacrifice of Isaac |
| E5* | Caravaggio — Bacchus |

`*` For E4, E5 and D23, current visitor-map labels are used for navigation when they differ from older artwork-catalogue pages; see `content/sources.json`.

### Route room-code coverage

- `florence.uffizi-90min`: 12 artwork stops; all 12 now resolve to a room code through their artwork records.
- `florence.uffizi-complete-3h`: 25 artwork stops; all 25 now resolve to a room code through their artwork records. Its stop order was normalized to the verified room-code sequence.
- City routes that include the Uffizi as a whole-museum stop do not imply a particular artwork room.

## v15 validation notes

- Updated manifest file list, byte sizes and SHA-256 hashes for all packaged files.
- JSON parsing passed for all pack JSON files; artwork IDs, route stop references, room IDs, room relations and media resource paths were checked.
- This is a city-pack data validation, not an Xcode build or an in-app UI/integration test. Indoor artwork coordinates remain null by design.


## Florence v16 — Uffizi interactive floor plans

- `media/images/uffizi-floor-plan-first.png` and `media/images/uffizi-floor-plan-second.png` are the local floor-plan assets for Phase 13.3.
- The matching floor nodes include `role: "floorPlan"` media references.
- All 25 curated Uffizi artwork nodes have normalized `spatialContext.indoorX` / `indoorY` points and matching `floorID` / `roomID` references. Coordinates place each marker inside its labeled room or merged room group; they are room-level approximations, not surveyed wall locations.
- Pack version: 16; schema version: 3.


## PHASE 2 working checkpoint (2026-10-23)

- Added Baptistery of San Giovanni, Giotto’s Bell Tower, Palazzo Medici Riccardi and Orsanmichele as four localized city-core nodes with explicit canonical IDs, priorities, coordinates, TR/EN short and standard guide text, and source references.
- Root discovery list expanded from 44 to 48; global content-node count is 108. Existing canonical IDs, relation graph, collections, audio files, image assets and Uffizi’s 25 artwork nodes are preserved.
- Opera del Duomo Museum and Museo di San Marco remain planned for PHASE 3 museum coverage. Shopping and food/experience additions remain for their later phases.
- `pre-audio` validator currently passes with 20 existing placeholder-image warnings; the working tree must still pass the remaining content phases and final production assembly before release.


## PHASE 5 working checkpoint — Florence v22 (2026-10-23)

- Preserved all six existing canonical route IDs and their existing stop IDs. The Uffizi extended route keeps its historical ID `florence.uffizi-complete-3h`; its visible TR/EN title and `routeEstimatedMinutes=240` consistently describe a four-hour route. The ID was not renamed because collection IDs are canonical references.
- Reordered `florence.golden-hour-route` so Gelateria La Carraia is a pre-climb stop and Piazzale Michelangelo is the final stop.
- Added `florence.accademia-highlights-60min` (8 existing artwork stops) and `florence.opera-duomo-highlights-60min` (6 existing artwork stops). Both use `kind = museumRoute` and ordered `nodeIDs`, with no invented artwork location metadata.
- Removed unsubstantiated `routeDistanceMeters` values from route definitions because the current source ledger does not contain a directly verified routing-distance source. Estimated durations remain; the distance field is optional in the current Swift model.
- No `follows` relations were added: route stop order is already explicitly encoded by the ordered `CollectionDefinition.nodeIDs` array, and the app's route detail consumes this array.
- No artwork, POI, story, audio resource, image asset, floor-plan asset or indoor-coordinate value was changed in PHASE 5.
- Updated pack version to 22; schema version remains 4. This is a content working checkpoint, not a final publishing handoff or Xcode/device test.
