# Florence v2 — Multi-JSON Content Pack

This pack uses the Leylek multi-document content contract. Documents are split by editorial boundary rather than individual artwork.

- content/index.json — content document index
- content/city/florence.json — city metadata and city-level places
- content/places/uffizi.json — Uffizi museum node and visitor note
- content/museums/uffizi/floor-2.json — second-floor rooms and artworks
- content/museums/uffizi/floor-1.json — first-floor rooms and artworks
- content/routes/uffizi.json — curated Uffizi route collections

The app merges these documents into the existing CityContentPack model, so the UI and ContentRepository APIs remain unchanged.


Version 3 additions:
- Galleria dell’Accademia content document with Gallery of the Prisoners, Tribune of David and Michelangelo's David.
- Duomo description updated with the 1296–1436 construction range.
