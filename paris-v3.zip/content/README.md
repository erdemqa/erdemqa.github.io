# Paris City Pack — incremental working build

Pack ID: `paris`

Pack version: `3`

Schema version: `3`

This is an incremental working pack, not the final production release. `content/index.json` is the canonical content discovery list. Current indexed content contains 106 ContentNodes, 80 ContentRelations and 55 city root nodes, including 12 museum nodes and 51 curated artworks. Artwork documents contain 20 Louvre works, 9 Musée d’Orsay works, 8 Musée de l’Orangerie works, 8 Musée Rodin works and 6 Musée de Cluny tapestries from *The Lady and the Unicorn* set. PHASE 4 covers neighborhoods, food/venues, standalone experiences and selected cultural/nature places. PHASE 5 adds six ordered route definitions.

No image assets were acquired. Empty `media` arrays are intentional and schema-valid. `content/sources.json` is audit metadata and is not a consumer content document.

## Artwork documents

- `artworks/paris-louvre-artworks.json`: 20 works; six have bilingual deepText.
- `artworks/paris-orsay-artworks.json`: 9 works; five have bilingual deepText.
- `artworks/paris-orangerie-artworks.json`: 8 works; five have bilingual deepText. The Water Lilies cycle is one canonical node for the eight-composition ensemble.
- `artworks/paris-rodin-artworks.json`: 8 selected works; five have bilingual deepText. The Burghers of Calais node is contextual only because the official record locates the referenced plaster model at Meudon; it is not marked as a visit target at the Paris site.
- `artworks/paris-cluny-artworks.json`: six *Lady and the Unicorn* tapestries; Touch and À mon seul désir have bilingual deepText. The sixth panel's meaning is presented as debated rather than settled.

All artwork nodes are bilingual, have one canonical GuideContent and include object-level source references. Room/floor placement and images are intentionally omitted pending separate verification. Artwork nodes do not become city roots. Remaining work includes PHASE 6 comprehensive source audit, PHASE 7 independent full-pack quality/audio audit and PHASE 8 clean production staging and release validation.


PHASE 4 progress note (2026-10-11): neighbourhood and urban-space batch 1 is declared in `content/index.json` at `content/places/paris-phase4-urban-areas.json`. This is an intermediate pack, not a final production release. Current access conditions for parks, businesses and activities must be rechecked before travel.


PHASE 4 progress note (2026-10-11): food-market, café, bakery, dessert and restaurant entities are declared in `content/index.json` at `content/venues/paris-food-venues.json`. Current opening hours, prices and other volatile business details are intentionally omitted from persistent metadata; recheck official venue pages before travel. This remains an intermediate pack.


## PHASE 5 routes

Six route definitions are stored in `city/paris.json` under `collections` and are discovered via `content/index.json`: four `cityRoute` collections and two `museumRoute` collections. Their ordered stops are encoded by each collection’s `nodeIDs` array. Route distances are omitted because no verified route-engine measurement was available. The Louvre duration is backed by its official 90-minute visitor trail; the Orsay 90-minute value is an editorial target, with a subtitle warning that the sequence is curatorial rather than a guaranteed room-to-room path. Routes are exposed by the app collection repository and Explore collections section, not as ContentNode roots.


## Source audit status (2026-10-11)

The source register was reviewed for coverage, source hierarchy, URL duplication, verification dates and current-sensitive visitor information. Each content node has at least one Tier 1 source; every node external-reference URL is represented in `sources.json`. Temporary hours, prices, schedules, exhibition availability and room/floor data are not embedded as permanent claims. See the separately delivered PHASE 6 source-audit report for currentness checks and known non-blocking follow-ups.
