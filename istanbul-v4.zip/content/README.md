# Leylek Istanbul City Pack

Production content pack migrated to the current Leylek consumer contract from the supplied schema-v3 project.

Schema version: 3
Pack version: 2

The pack uses `content/index.json` as its canonical content-discovery manifest. City-specific image acquisition remains outside this content migration; existing media references were checked and backup-only assets were excluded from the production ZIP.
