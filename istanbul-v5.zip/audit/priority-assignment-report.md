# Istanbul v5 — Editorial Priority Assignment Audit

- Source pack: Istanbul v4 (`schemaVersion: 3`)
- Output pack: Istanbul v5 (`schemaVersion: 3`)
- Nodes classified: 173
- Priority enum: `must_see`, `highly_recommended`, `recommended`, `local_gem`, `optional`
- Structural `floor`, `room`, `gallery`, and `artCollection` nodes are `optional` so they do not receive a visitor-facing priority badge.
- Existing `city-icon` tags map to `must_see`; existing `hidden-gem` tags map to `local_gem`.
- Other values are editorial recommendations based on current pack content, curation context, and city-guide usefulness; they are not claims of objective rankings.

## Distribution

| Priority | Count |
|---|---:|
| Must See (`must_see`) | 24 |
| Highly Recommended (`highly_recommended`) | 73 |
| Recommended (`recommended`) | 25 |
| Hidden Gem (`local_gem`) (`local_gem`) | 8 |
| Optional / no badge (`optional`) | 43 |

## Notes

All indexed `ContentNode` records carry an explicit `priority`. Pack schema remains v3; pack and content index version are bumped to 5. See the accompanying priority list delivered with the pack for node-level IDs, names, values, and rationale.
