import json, csv, hashlib, zipfile, shutil
from pathlib import Path
from collections import Counter

ROOT=Path('/mnt/data/istanbul_priority_work')
CONTENT=ROOT/'content'

# Explicit editorial decisions for non-structural content; values follow Leylek's priority enum.
priority_map = {
# City-signature sites and core attractions
'istanbul.attraction.spice-bazaar': ('highly_recommended','Tarihi gastronomi ve çarşı deneyimi; şehir simgelerine tamamlayıcı.'),
'istanbul.attraction.suleymaniye-mosque': ('must_see','İstanbul’un başlıca Sinan/Ottoman mimarlık anıtlarından biri.'),
'istanbul.historical-site.kariye': ('highly_recommended','Bizans mozaik ve fresk mirası açısından çok güçlü bir ziyaret noktası.'),
# Experiences
'istanbul.experience.bosphorus-ferry': ('must_see','İstanbul’un coğrafyasını ve iki kıta bağlantısını deneyimleten imza etkinlik.'),
'istanbul.experience.long-bosphorus-tour': ('highly_recommended','Boğaz kıyılarını ve anıtsal yapıları kapsamlı biçimde deneyimletir.'),
'istanbul.experience.princes-islands-day-trip': ('highly_recommended','Şehir merkezinden farklı, İstanbul’a özgü güçlü günlük gezi.'),
'istanbul.experience.historic-peninsula-walk': ('must_see','Tarihi yarımadanın ana miras alanlarını bir araya getirir.'),
'istanbul.experience.fener-balat-heritage-walk': ('highly_recommended','Çok katmanlı kent mirasını ve mahalle dokusunu keşfetmek için güçlü rota.'),
'istanbul.experience.galata-karakoy-walk': ('highly_recommended','Merkezi kültür, mimari ve kent yaşamını birleştiren rota.'),
'istanbul.experience.historic-hammam': ('highly_recommended','İstanbul/Türk hamam geleneğini deneyimlemeye yönelik karakteristik etkinlik.'),
'istanbul.experience.meyhane-culture': ('highly_recommended','İstanbul’un yemek ve akşam kültürünü temsil eden özgün deneyim.'),
'istanbul.experience.turkish-coffee-ritual': ('recommended','Kültürel değeri yüksek, ancak belirli bir tek mekâna bağlı olmayan deneyim.'),
'istanbul.experience.galata-mevlevi-heritage': ('highly_recommended','Mevlevi kültürü ve müzik geleneğini anlamak için anlamlı deneyim.'),
'istanbul.experience.tea-hospitality': ('recommended','Gündelik yerel kültür açısından değerli, daha hafif kapsamlı deneyim.'),
'istanbul.experience.istanbul-street-food': ('highly_recommended','Şehir gastronomisini birden çok durakla keşfetmeye yönelik kapsamlı deneyim.'),
# Main landmark layer
'istanbul.landmark.hippodrome': ('must_see','Tarihi yarımadanın Roma/Bizans tarihini anlatan merkezi alanı.'),
'istanbul.landmark.galata-bridge': ('recommended','Kent yaşamı ve Haliç manzarası açısından anlamlı tamamlayıcı durak.'),
'istanbul.landmark.istiklal-caddesi': ('highly_recommended','Beyoğlu’nun kent kültürü ve mimari katmanlarını temsil eden ana cadde.'),
'istanbul.attraction.theodosian-land-walls': ('highly_recommended','Bizans savunma tarihi ve UNESCO alanı bağlamı için önemli.'),
'istanbul.attraction.rumeli-fortress': ('highly_recommended','Boğaz tarihini ve Osmanlı fetih hazırlıklarını anlatan anıtsal yapı.'),
'istanbul.attraction.ortakoy-mosque': ('highly_recommended','Boğaz kıyısı mimarisi ve kent siluetiyle öne çıkan cami.'),
'istanbul.viewpoint.camlica-hill': ('recommended','Güçlü panoramik manzara; ana kültürel duraklara tamamlayıcı.'),
'istanbul.viewpoint.pierre-loti': ('highly_recommended','Haliç manzarası ve Eyüp çevresiyle ilişkili tanınmış seyir noktası.'),
'istanbul.attraction.buyukada': ('highly_recommended','Adalar’ın kent dışı günlük gezi ve kültürel peyzaj deneyimi.'),
# Museum-level priorities
'istanbul.museum.topkapi-palace': ('must_see','İmparatorluk tarihi ve koleksiyon derinliğiyle İstanbul’un temel müzelerinden.'),
'istanbul.museum.istanbul-archaeology': ('must_see','Antik Akdeniz ve Anadolu arkeolojisi için temel müze kompleksi.'),
'istanbul.museum.turkish-islamic-art': ('must_see','Halı, yazma, ahşap ve taş eser koleksiyonlarıyla ayırt edici ana müze.'),
'istanbul.museum.dolmabahce-palace': ('must_see','Geç Osmanlı saray mimarisi ve dekoratif sanatlar için başlıca ziyaret noktası.'),
'istanbul.museum.istanbul-modern': ('highly_recommended','Modern ve çağdaş Türkiye sanatını anlamak için önde gelen müze.'),
'istanbul.museum.pera-museum': ('highly_recommended','Önemli oryantalist resim ve Kütahya seramik koleksiyonlarıyla güçlü müze.'),
'istanbul.museum.sakip-sabanci': ('highly_recommended','Sanat, hat ve Boğaz kıyısı kültürel deneyimini birleştiren müze.'),
'istanbul.museum.yildiz-palace': ('highly_recommended','Geç Osmanlı saray kültürü açısından önemli tamamlayıcı durak.'),
'istanbul.museum.rahmi-koc': ('highly_recommended','Sanayi, ulaşım ve teknoloji tarihini kapsamlı biçimde sunar.'),
'istanbul.museum.great-palace-mosaic': ('highly_recommended','Bizans Büyük Saray mozaikleri açısından özgün ve uzmanlaşmış müze.'),
'istanbul.museum.islamic-science-history': ('highly_recommended','İslam bilim ve teknoloji tarihini açıklayan özgün koleksiyon.'),
'istanbul.museum.galata-mevlevi-lodge': ('highly_recommended','Mevlevi kültürü, müzik ve edebiyat mirası açısından önemli.'),
'istanbul.museum.borusan-contemporary': ('recommended','Çağdaş/new-media sanatı için niş ve tamamlayıcı müze.'),
'istanbul.museum.istanbul-toy-museum': ('recommended','Aileler ve tasarım/tarih meraklıları için özel ilgi alanlı müze.'),
'istanbul.museum.museum-of-innocence': ('highly_recommended','Orhan Pamuk’un romanı ve İstanbul’un gündelik hafızasıyla özgün bağ kurar.'),
'istanbul.museum.beylerbeyi-palace': ('highly_recommended','Boğaz kıyısında geç Osmanlı saray mimarisi için güçlü ziyaret noktası.'),
'istanbul.museum.istanbul-archaeology.archaeology': ('highly_recommended','Arkeoloji Müzeleri kompleksi içindeki ana arkeoloji binası.'),
'istanbul.museum.istanbul-archaeology.ancient-orient': ('highly_recommended','Eski Yakın Doğu uygarlıklarına ait önemli koleksiyonları barındırır.'),
'istanbul.museum.istanbul-archaeology.tiled-kiosk': ('recommended','Kompleks içindeki tarihî mimarlık ve çini koleksiyonunu tamamlar.'),
# Neighborhoods
'istanbul.sultanahmet': ('must_see','Tarihi yarımadanın başlıca anıtlarını bir araya getiren çekirdek bölge.'),
'istanbul.eminonu': ('highly_recommended','Tarihî ticaret, iskeleler ve çarşı kültürü açısından merkezi bölge.'),
'istanbul.fener-balat': ('highly_recommended','Çok kültürlü mimari ve mahalle mirasıyla öne çıkan bölge.'),
'istanbul.galata': ('highly_recommended','Tarihî kent dokusu, kule çevresi ve kültürel yaşam açısından ana bölge.'),
'istanbul.karakoy': ('highly_recommended','Liman tarihi, sanat ve gastronomi bağlamını birleştirir.'),
'istanbul.kadikoy': ('highly_recommended','Anadolu yakasında yeme-içme, pazar ve kent yaşamı için önemli merkez.'),
'istanbul.moda': ('recommended','Sahil ve mahalle atmosferi için güzel, daha ikincil bölgesel öneri.'),
'istanbul.uskudar': ('highly_recommended','Tarihî kıyı silueti ve Osmanlı dini mimarisiyle önemli bölge.'),
'istanbul.kuzguncuk': ('local_gem','Küçük ölçekli, çok kültürlü mahalle dokusu ve yerel atmosfer.'),
'istanbul.nisantasi': ('recommended','Modern kent yaşamı ve alışveriş kültürü için tamamlayıcı mahalle.'),
# Parks / outdoor spaces
'istanbul.attraction.gulhane-park': ('highly_recommended','Tarihi yarımadadaki önemli tarihî bahçe ve dinlenme alanı.'),
'istanbul.attraction.yildiz-park': ('highly_recommended','Tarihî koru ve saray çevresi peyzajı açısından değerli.'),
'istanbul.attraction.emirgan-grove': ('highly_recommended','Boğaz kıyısı tarihî korusu ve peyzajıyla öne çıkar.'),
'istanbul.attraction.fethi-pasha-grove': ('local_gem','Daha sakin, yerel Boğaz korusu deneyimi.'),
'istanbul.attraction.ataturk-arboretum': ('recommended','Doğa ve yürüyüş odağında, ana tarihî rotalara tamamlayıcı.'),
'istanbul.attraction.belgrad-forest': ('recommended','Doğa ve yürüyüş için değerli, şehir merkezi ziyaretinden ayrı deneyim.'),
# Food and drink
'istanbul.venue.pandeli': ('highly_recommended','Tarihî lokanta ve Türk mutfağı deneyimiyle ayırt edici.'),
'istanbul.venue.karakoy-lokantasi': ('highly_recommended','İstanbul lokanta kültürü ve klasik Türk yemekleri için güçlü öneri.'),
'istanbul.venue.ciya-sofrasi': ('highly_recommended','Anadolu bölgesel mutfağı çeşitliliğiyle ayırt edici.'),
'istanbul.venue.hunkar': ('highly_recommended','Klasik Türk ev yemeği/lokanta geleneğiyle güçlü öneri.'),
'istanbul.venue.kanaat-lokantasi': ('recommended','Üsküdar’ın gündelik lokanta geleneği için anlamlı tamamlayıcı.'),
'istanbul.venue.giritli': ('highly_recommended','Meyhane ve Ege-Akdeniz yemek deneyimi açısından güçlü.'),
'istanbul.venue.neolokal': ('highly_recommended','Çağdaş Anadolu mutfağı ve yerel malzeme yaklaşımıyla öne çıkar.'),
'istanbul.venue.mikla': ('highly_recommended','Çağdaş Anadolu mutfağıyla bilinen önde gelen gastronomi noktası.'),
'istanbul.venue.fazil-bey': ('highly_recommended','Türk kahvesi geleneğini deneyimlemek için karakteristik nokta.'),
'istanbul.venue.mandabatmaz': ('highly_recommended','İstanbul’un tanınmış Türk kahvesi duraklarından.'),
'istanbul.venue.karakoy-gulluoglu': ('highly_recommended','Baklava kültürü ve geleneksel tatlı için tanınmış adres.'),
# Dolmabahçe artworks
'istanbul.artwork.aivazovsky-constantinople-bosphorus': ('highly_recommended','Aivazovsky’nin İstanbul/Boğaz teması ve şehir bağlantısı güçlü.'),
'istanbul.artwork.aivazovsky-moonrise-golden-horn': ('highly_recommended','Aivazovsky’nin Haliç manzarası koleksiyonda görsel ve tarihî değer taşır.'),
'istanbul.artwork.aivazovsky-ottoman-armored-ship-bosphorus': ('recommended','Osmanlı denizcilik tarihiyle ilişkili anlamlı eser.'),
'istanbul.artwork.aivazovsky-winter-landscape': ('recommended','Sanatçı ve manzara bağlamını tamamlayan eser.'),
'istanbul.artwork.chlebowski-sultan-abdulaziz-portrait': ('highly_recommended','Osmanlı hükümdar portresi ve saray temsili açısından önemli.'),
'istanbul.artwork.abdulmecid-efendi-abdulhamid-painting': ('recommended','Geç Osmanlı hanedan portreciliği açısından tamamlayıcı eser.'),
'istanbul.artwork.dolmabahce-hereke-harem-carpet': ('highly_recommended','Saray tekstili ve Hereke dokumacılığı kültürüyle anlamlı.'),
'istanbul.artwork.dolmabahce-baccarat-ceremonial-chandelier': ('highly_recommended','Muayede Salonu’nun dekoratif sanat ve saray ihtişamını temsil eder.'),
# İstanbul Archaeology artworks
'istanbul.artwork.alexander-sarcophagus': ('must_see','Müzenin en tanınmış arkeolojik başyapıtlarından biri.'),
'istanbul.artwork.mourning-women-sarcophagus': ('highly_recommended','Sidon lahitleri grubunun sanatsal açıdan önemli örneği.'),
'istanbul.artwork.tabnit-sarcophagus': ('highly_recommended','Sidon koleksiyonunun tarihî/arkeolojik değeri yüksek eseri.'),
'istanbul.artwork.lycian-sarcophagus': ('recommended','Anadolu mezar sanatı bağlamını tamamlayan eser.'),
'istanbul.artwork.naram-sin-stele': ('highly_recommended','Akkad krallığı ve erken imparatorluk ikonografisi için önemli eser.'),
'istanbul.artwork.kadesh-peace-treaty': ('must_see','Hitit-Mısır diplomasi tarihini somutlaştıran ikonik belge.'),
'istanbul.artwork.ishtar-gate-relief': ('highly_recommended','Babil mimari dekorasyonu ve antik Yakın Doğu bağlamı açısından öne çıkar.'),
'istanbul.artwork.ibrahim-bey-mihrab': ('recommended','Selçuklu sonrası Anadolu çini ve dini mimarlık geleneğini temsil eder.'),
# İstanbul Modern artworks
'istanbul.artwork.my-hell': ('must_see','Fahrelnissa Zeid’in anıtsal soyut yaklaşımını temsil eden öne çıkan eser.'),
'istanbul.artwork.abstract-composition-nejad': ('highly_recommended','Türkiye modernizmi ve soyut sanat bağlamında önemli.'),
'istanbul.artwork.istanbul-aliye-berger': ('highly_recommended','Aliye Berger’in baskı sanatı ve kent yorumu açısından değerli.'),
'istanbul.artwork.the-magnificent-age': ('recommended','Modern Türkiye sanatındaki farklı görsel anlatımları tamamlar.'),
'istanbul.artwork.coffeehouse-bedri-rahmi': ('highly_recommended','Bedri Rahmi Eyüboğlu’nun halk kültürü ve modern sanat bağını yansıtır.'),
'istanbul.artwork.explosion-erol-akyavas': ('highly_recommended','Erol Akyavaş’ın modern sanat yaklaşımını temsil eden eser.'),
'istanbul.artwork.3-men-4-women-visitors': ('recommended','Koleksiyondaki tematik çeşitliliği tamamlayan eser.'),
'istanbul.artwork.beyoglu-ara-guler': ('highly_recommended','Ara Güler’in İstanbul kent belleği ve fotoğraf tarihiyle doğrudan ilişkili.'),
# Pera artworks
'istanbul.artwork.tortoise-trainer': ('must_see','Pera Müzesi’nin en ikonik ve koleksiyonla özdeşleşmiş eseri.'),
'istanbul.artwork.girl-with-pink-cap': ('recommended','Oryantalist resim koleksiyonunu tamamlayan portre.'),
'istanbul.artwork.view-of-istanbul-ziem': ('highly_recommended','İstanbul’un tarihî görsel temsili açısından anlamlı eser.'),
'istanbul.artwork.caiques-sailboats-bosphorus-ziem': ('highly_recommended','Boğaz’ın tarihî deniz yaşamını belgeleyen resim teması.'),
'istanbul.artwork.minas-avramidis-genovefa-plate': ('recommended','Kütahya seramikleri ve dekoratif sanatlar için örnek eser.'),
'istanbul.artwork.athens-kutahia-vase': ('recommended','Kütahya çini/seramik koleksiyonunun tamamlayıcı örneği.'),
# Topkapı artworks
'istanbul.artwork.spoonmakers-diamond': ('must_see','Topkapı Sarayı hazinesinin en ikonik eserlerinden.'),
'istanbul.artwork.topkapi-dagger': ('must_see','Topkapı Hazinesi ile özdeşleşen, uluslararası bilinirliği yüksek eser.'),
'istanbul.artwork.culus-throne': ('highly_recommended','Osmanlı cülus ve saray törenlerini temsil eden önemli nesne.'),
'istanbul.artwork.quran-attributed-to-uthman': ('highly_recommended','Kutsal emanetler ve erken Kur’an geleneğiyle bağlantılı eser; atıf ihtiyatıyla.'),
'istanbul.artwork.prophets-letter-holy-relics': ('highly_recommended','Kutsal emanetler koleksiyonundaki tarihî ve dinî açıdan önemli nesne.'),
'istanbul.artwork.selimi-ii-kaftan': ('highly_recommended','Osmanlı saray giyimi ve tekstil tarihi açısından önemli.'),
'istanbul.artwork.costanzo-mehmed-h2153': ('highly_recommended','Fatih Sultan Mehmed’in görsel temsili ve saray albümü bağlamı açısından değerli.'),
# Turkish and Islamic Arts artworks
'istanbul.artwork.tiem-konya-carpet-681': ('highly_recommended','Anadolu Selçuklu halı geleneğinin önemli koleksiyon örneği.'),
'istanbul.artwork.tiem-konya-carpet-685': ('highly_recommended','Selçuklu halı grubunu karşılaştırmalı anlamak için önemli örnek.'),
'istanbul.artwork.tiem-konya-carpet-689': ('highly_recommended','Selçuklu halı koleksiyonunun tarihî ve sanatsal değerini tamamlar.'),
'istanbul.artwork.tiem-sarcophagus-1251-1252': ('highly_recommended','Selçuklu ahşap işçiliği ve kitabe geleneği açısından önemli.'),
'istanbul.artwork.tiem-woman-bust-seljuk': ('recommended','Selçuklu figürlü taş sanatının koleksiyondaki örneği.'),
'istanbul.artwork.tiem-griffin-relief': ('recommended','Hayvan figürlü taş kabartma ve simgesel motifler açısından tamamlayıcı.'),
'istanbul.artwork.tiem-she4141-quran-scroll': ('highly_recommended','Kufi hat ve Kur’an yazmaları koleksiyonunda önemli eser.'),
'istanbul.artwork.tiem-minbar-side-245': ('recommended','Ahşap minber işçiliğini ve geometrik süslemeyi temsil eden örnek.'),
}

priority_enum={'must_see','highly_recommended','recommended','local_gem','optional'}
structural_kinds={'floor','room','gallery','artCollection'}

# Load all content documents listed in the current index; ensure every node gets an explicit value.
index_path=CONTENT/'index.json'
index=json.loads(index_path.read_text(encoding='utf-8'))
content_files=list(index['contentFiles'])
all_records=[]
for rel in content_files:
    path=ROOT/rel
    data=json.loads(path.read_text(encoding='utf-8'))
    if 'version' in data:
        data['version']=5
    for n in data.get('nodes',[]):
        nid=n['id']; kind=n.get('kind'); cats=n.get('categoryIDs') or []
        if kind in structural_kinds:
            priority='optional'; reason='Kat/oda/galeri/koleksiyon hiyerarşisi; bağımsız ziyaret önerisi olarak etiketlenmez.'
        elif 'hidden-gem' in cats:
            priority='local_gem'; reason='City pack içindeki mevcut hidden-gem editoryal işareti.'
        elif 'city-icon' in cats:
            priority='must_see'; reason='City pack içindeki mevcut city-icon işareti; şehrin simgesel çekirdek içeriği.'
        elif nid in priority_map:
            priority,reason=priority_map[nid]
        else:
            raise ValueError(f'No priority decision for {nid} ({kind}) in {rel}')
        if priority not in priority_enum:
            raise ValueError(f'Invalid priority {priority} for {nid}')
        n['priority']=priority
        loc=n.get('localizedName') or {}; vals=loc.get('values',{}) if isinstance(loc,dict) else {}
        all_records.append({'source':rel,'id':nid,'name_tr':vals.get('tr',''),'name_en':vals.get('en',''),'kind':kind,'priority':priority,'rationale':reason})
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

if len(all_records)!=173:
    raise ValueError(f'Expected 173 nodes, got {len(all_records)}')
if len({r['id'] for r in all_records}) != len(all_records):
    raise ValueError('Duplicate IDs')
if {r['id'] for r in all_records} != {r['id'] for r in all_records}:
    raise ValueError('ID validation failure')

# Bump content index and pack manifest, retaining schema v3.
index['version']=5
index_path.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
manifest_path=ROOT/'manifest.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
manifest['version']=5
manifest['schemaVersion']=3
# Refresh hashes/sizes for every existing file path plus report to be added below.

dist_counts=Counter(r['priority'] for r in all_records)
# Create self-contained audit report inside pack; CSV/MD downloads also produced beside final ZIP.
report_lines=[
'# Istanbul v5 — Editorial Priority Assignment Audit',
'',
'- Source pack: Istanbul v4 (`schemaVersion: 3`)',
'- Output pack: Istanbul v5 (`schemaVersion: 3`)',
'- Nodes classified: 173',
'- Priority enum: `must_see`, `highly_recommended`, `recommended`, `local_gem`, `optional`',
'- Structural `floor`, `room`, `gallery`, and `artCollection` nodes are `optional` so they do not receive a visitor-facing priority badge.',
'- Existing `city-icon` tags map to `must_see`; existing `hidden-gem` tags map to `local_gem`.',
'- Other values are editorial recommendations based on current pack content, curation context, and city-guide usefulness; they are not claims of objective rankings.',
'',
'## Distribution',
'',
'| Priority | Count |',
'|---|---:|',
]
for k,label in [('must_see','Must See'),('highly_recommended','Highly Recommended'),('recommended','Recommended'),('local_gem','Hidden Gem (`local_gem`)'),('optional','Optional / no badge')]:
    report_lines.append(f'| {label} (`{k}`) | {dist_counts[k]} |')
report_lines += ['', '## Notes', '',
'All indexed `ContentNode` records carry an explicit `priority`. Pack schema remains v3; pack and content index version are bumped to 5. See the accompanying priority list delivered with the pack for node-level IDs, names, values, and rationale.', '']
report_path=ROOT/'audit'/'priority-assignment-report.md'
report_path.write_text('\n'.join(report_lines),encoding='utf-8')

# Create node-level CSV and Markdown list outside the content tree as companion deliverables.
output_csv=Path('/mnt/data/istanbul-v5-priority-list.csv')
with output_csv.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['source','id','name_tr','name_en','kind','priority','rationale'])
    w.writeheader();w.writerows(all_records)
output_md=Path('/mnt/data/istanbul-v5-priority-list.md')
md=['# İstanbul v5 — Priority list','',f'Total: **{len(all_records)} nodes**. Schema v3.','', '## Distribution','', '| Priority | Count |','|---|---:|']
for k,label in [('must_see','Must See'),('highly_recommended','Highly Recommended'),('recommended','Recommended'),('local_gem','Hidden Gem (`local_gem`)'),('optional','Optional / no badge')]: md.append(f'| {label} (`{k}`) | {dist_counts[k]} |')
md += ['', '## All nodes', '', '| Source file | Node ID | Türkçe ad | English name | Kind | Priority | Gerekçe |','|---|---|---|---|---|---|---|']
for r in all_records:
    def esc(x): return str(x).replace('|','\\|').replace('\n',' ')
    md.append('| '+' | '.join(esc(r[k]) for k in ['source','id','name_tr','name_en','kind','priority','rationale'])+' |')
md.append('')
output_md.write_text('\n'.join(md),encoding='utf-8')

# Write separate audit JSON too.
report_json=ROOT/'audit'/'priority-assignment-report.json'
report_json.write_text(json.dumps({'packID':'istanbul','version':5,'schemaVersion':3,'nodeCount':len(all_records),'priorityCounts':dict(dist_counts),'assignments':all_records},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Add new audit report files to manifest; refresh file table based on current archive tree excluding manifest itself.
existing={entry['path']:entry for entry in manifest.get('files',[])}
all_files=sorted([p for p in ROOT.rglob('*') if p.is_file() and p.relative_to(ROOT).as_posix()!='manifest.json'])
file_entries=[]
for p in all_files:
    rel=p.relative_to(ROOT).as_posix()
    blob=p.read_bytes()
    file_entries.append({'path':rel,'sizeBytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()})
manifest['files']=file_entries
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Validate all content JSON and priority fields.
parsed_nodes=[]
for rel in content_files:
    data=json.loads((ROOT/rel).read_text(encoding='utf-8'))
    if data.get('version') != 5 or data.get('schemaVersion') != 3:
        raise ValueError(f'Wrong version/schema in {rel}: {data.get("version")} / {data.get("schemaVersion")}')
    for n in data.get('nodes',[]):
        if n.get('priority') not in priority_enum:
            raise ValueError(f'Missing/invalid priority in {rel}: {n.get("id")} -> {n.get("priority")}')
        parsed_nodes.append(n)
if len(parsed_nodes)!=173: raise ValueError('Post-save node count mismatch')
# Confirm relation/parent targets resolve within indexed graph except cityID root (city node id exists too).
ids={n['id'] for n in parsed_nodes}
missing_parents=[]; missing_relations=[]
for rel in content_files:
 data=json.loads((ROOT/rel).read_text(encoding='utf-8'))
 for n in data.get('nodes',[]):
  pid=n.get('parentID')
  if pid and pid not in ids: missing_parents.append((rel,n['id'],pid))
 for r in data.get('relations',[]):
  for k in ['sourceID','targetID']:
   target=r.get(k)
   if target and target not in ids: missing_relations.append((rel,r,k,target))
if missing_parents: raise ValueError(f'Broken parents: {missing_parents[:3]}')
# Existing packs may intentionally use some relation reference IDs outside node graph; report rather than block if any.

# Recheck manifest all paths, size, sha
for e in manifest['files']:
 p=ROOT/e['path']; blob=p.read_bytes()
 if len(blob)!=e['sizeBytes'] or hashlib.sha256(blob).hexdigest()!=e['sha256']:
  raise ValueError(f'Manifest mismatch {e["path"]}')

# Make production zip at root. Use reproducible-ish file ordering and omit no files because source pack already clean.
zip_path=Path('/mnt/data/istanbul-v5.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted([p for p in ROOT.rglob('*') if p.is_file()]):
  arc=p.relative_to(ROOT).as_posix()
  z.write(p,arc)
# Changed files zip: new changed JSON content docs, manifest/index, audit report, avoid assets.
changed=Path('/mnt/data/istanbul-v5-changed-files.zip')
changed_paths=set(content_files + ['manifest.json','content/index.json','audit/priority-assignment-report.md','audit/priority-assignment-report.json'])
with zipfile.ZipFile(changed,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel in sorted(changed_paths): z.write(ROOT/rel,rel)
# summary report
summary=Path('/mnt/data/istanbul-v5-priority-audit.md')
summary.write_text('\n'.join(report_lines + ['', '## Validation', '', '- All 173 nodes have valid explicit priority values.', '- All indexed content JSON documents decode as JSON and use version 5 / schema v3.', '- Manifest size and SHA-256 values were recalculated and checked.', '- ZIP archive integrity is checked after packaging.', '- No city content/media was deleted or modified except priority-related JSON, version metadata, manifest, and audit reports.', '']),encoding='utf-8')

# Final zip integrity test
with zipfile.ZipFile(zip_path) as z:
 bad=z.testzip()
 if bad: raise ValueError(f'ZIP CRC failure: {bad}')
print('SUCCESS')
print('node_count',len(all_records))
print('distribution',dict(dist_counts))
print('files_in_manifest',len(manifest['files']))
print('content_files',len(content_files))
print('missing_parents',len(missing_parents),'unresolved relation refs',len(missing_relations))
print('zip_size',zip_path.stat().st_size)
print('zip_test',bad)
print('unknown_priority_map_remaining',set(r['id'] for r in all_records if r['id'] not in priority_map))
