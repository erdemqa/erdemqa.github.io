# Leylek Istanbul City Pack

Content-authoring handoff for the supplied Leylek consumer contract.

- Pack ID: `istanbul`
- Pack version: `13`
- Schema version: `4`

`content/index.json` is the canonical runtime content discovery list. The manifest separately describes every file shipped in this handoff, including media, license/attribution records, release notes, and the final QA report. Image-source registries are retained to preserve attribution for bundled media; entries for Openverse assets that are not present in the pack have been removed. No image files were acquired, generated, replaced, or edited in PHASE 8.

Audio generation and audio-resource processing are separate downstream responsibilities of `leylek_pack_flow`; this content handoff does not generate or alter audio.

Root visibility update v13: all 22 previously flagged coordinate-bearing top-level POIs were added to city.rootContentNodeIDs by explicit user instruction. No node content, media bytes, or audio resources were changed in this update.
