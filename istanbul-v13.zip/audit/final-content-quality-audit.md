# İstanbul City Pack — PHASE 8 Final Content Handoff Audit

**Tarih:** 23 Ekim 2026  
**Hedef:** `istanbul` · **Paket:** v13 · **Şema:** v4  
**Sonuç:** **PASS WITH WARNINGS**  
**İçerik handoff kararı:** `CONTENT AUTHORING READY FOR PACK_FLOW`

## PHASE 8 staging sonucu

- Temiz içerik handoff ZIP'i, sağlanan `leylek_pack_flow` publisher modülünün yerel `--no-upload` yolu ile oluşturuldu. GitHub'a yükleme yapılmadı; master pipeline çalıştırılmadı.
- `apply_priority.py` ve `inventory.tsv` çalışma/yardımcı dosyaları handoff paketinden çıkarıldı.
- `content/LICENSES.txt` içinde kaynak gösterildikleri için `content/openverse-images.json` ve `content/wikimedia-commons-images.json` attribution kayıtları korundu. Her iki kayıttaki `packVersion` son olarak v13 ile eşitlendi. Pakette bulunmayan üç Openverse dosya kaydı temizlendi; mevcut dosyalardan hiçbiri değiştirilmedi.
- `content/README.md` v13/schema v4 ile güncellendi. `metadata/release-notes.json` ve iç QA raporları son dataset'i yansıtacak şekilde yenilendi.
- Manifest, yalnızca temiz staging ağacından yeniden üretildi. Son ZIP açılarak manifest ile içerik birebir karşılaştırıldı; 228 dosyanın yolları, boyutları, SHA-256 değerleri ve ZIP CRC kontrolleri geçti.
- Paket halen pre-audio handoff'tur. Audio üretilmedi, `audioResources` alanları değiştirilmedi; görsel indirme/üretme/değiştirme yapılmadı.

## Ana envanter

| Metrik | Sonuç |
|---|---:|
| İndekslenmiş içerik JSON'u | 21 |
| Canonical node / benzersiz ID | 200 / 200 |
| İlişki | 130 |
| Root ID | 104 |
| Collection / route | 4 |
| Müze-kind node'u | 19 |
| Eser node'u | 45 |
| Story node'u | 5 |
| Kaynak kaydı | 158 |
| Medya dosyası | 198 |
| Açık paketin manifest girdisi | 228 (+ manifest.json) |

### Öncelik dağılımı

| `priority` | Düğüm |
|---|---:|
| `must_see` | 25 |
| `highly_recommended` | 86 |
| `recommended` | 31 |
| `optional` | 48 |
| `local_gem` | 10 |

200 düğümün tümünde bir geçerli `priority` alanı var. Kullanıcı tarafından onaylanan İstanbul Modern `must_see` istisnası korunuyor.

## Validation Gate

| Kontrol | Sonuç |
|---|---|
| JSON parse | PASS — paket genelinde parse hatası 0 |
| JSON duplicate key | PASS — 0 |
| Canonical index | PASS — 21 dosyanın tamamı mevcut; fazladan runtime content JSON yok |
| Swift model decode | PASS — gerçek Swift `Codable` modelleriyle 21 belge başarıyla decode edildi |
| Graph / root / collection refs | PASS — duplicate ID 0, dangling root/parent/relation 0 |
| Priority / enum uyumu | PASS — eksik veya geçersiz `priority` 0; desteklenmeyen tür/raw value 0 |
| Koordinatlar / indoor referansları | PASS — 75 koordinat, 5 `spatialContext`; geçersiz referans yok |
| Medya referansları | PASS — 198 referansın tamamı yerel dosyaya çözülüyor |
| Kaynak envanteri | PASS WITH LIMITATION — 158 kayıtta URL ve doğrulama tarihi var; URL biçimi kontrol edildi, her URL canlı olarak tekrar açılmadı |
| Pack-flow `pre-audio` validator | PASS WITH WARNINGS — 0 hata, 54 uyarı |
| Manifest / ZIP | PASS — 228 dosya girdisi, eksik/fazla yol veya hash uyuşmazlığı yok |
| Tam Xcode derlemesi / gerçek cihaz | Yapılmadı — bu Linux ortamında `xcodebuild` mevcut değil |

## Guide text ve City Stories

692 dolu, yerelleştirilmiş guide-tier metin değeri incelendi; mevcut tier metinleri v9 aralıklarında.

| Katman | Denetlenen değer | Min / Medyan / Maksimum | Sözleşme |
|---|---:|---:|---|
| `shortText` | 400 | 50 / 58 / 70 | 50–70 |
| `standardText` | 196 | 180 / 196 / 220 | 180–220 |
| `deepText` | 96 | 350 / 395 / 450 | 350–450 |

- Beş City Story'nun TR ve EN kısa/standart/detaylı katmanlarının tamamı aralıkta; her dilde `deepText`, `standardText` uzunluğunun en az 1,5 katı.
- Hikâye `relatedPlaceIDs` hedefleri geçerli; hikâyeler root veya rota içine yanlışlıkla alınmıyor.
- Aynı tier'da tam cümle/paragraf tekrarı: **0**.
- Üç veya daha fazla varlıkta tekrarlanan ilk beş kelimelik açılış: **0**.
- İlk cümle benzerliği için %84+ eşiğinde işaretlenen çift: **0**.
- Denetim yöntemi: programatik metrik ve tekrar taraması; yerel inceleme eşliğinde. Bu rapor dış URL'lerin tamamının canlı erişimini iddia etmez.

## Şehir profili, kaynaklar ve hikâyeler

- Şehir özeti TR/EN mevcut; **6** quick fact'in etiketi ve değeri iki dilde dolu.
- Kaynak envanterinde **158** kayıt var; URL veya doğrulama tarihi eksik kayıt 0. PHASE 8'de her adres yeniden canlı olarak açılmadı; dolayısıyla alan/biçim kontrolü linkin bugün erişilebilir olduğunu garanti etmez.
- Beş hikâye: Kız Kulesi efsanesi (`legend`), Hezârfen anlatısı (`traditionalAccount`), Haliç zinciri ve gemilerin karadan taşınması (`documentedHistory`), Medusa başları (`documentedHistory`), Pierre Loti Tepesi (`documentedTradition`). Kanıt durumları içerikte ayrıştırılıyor.

### Hikâye kelime kontrolü

| Story ID | TR kısa / standart / detaylı | EN kısa / standart / detaylı | Kanıt durumu |
|---|---:|---:|---|
| `istanbul.story.maidens-tower-princess-legend` | 54 / 184 / 353 | 67 / 212 / 419 | `legend` |
| `istanbul.story.hezarfen-galata-uskudar-account` | 53 / 181 / 356 | 56 / 196 / 436 | `traditionalAccount` |
| `istanbul.story.golden-horn-chain-and-overland-ships` | 54 / 180 / 352 | 69 / 220 / 429 | `documentedHistory` |
| `istanbul.story.medusa-heads-reused-in-cistern` | 58 / 191 / 357 | 70 / 220 / 448 | `documentedHistory` |
| `istanbul.story.pierre-loti-hill-memory` | 53 / 183 / 354 | 69 / 200 / 429 | `documentedTradition` |

## Gastronomi, alışveriş ve müzeler

- Yiyecek-içecek venue düğümleri: 21 restoran, 3 kafe, 1 tatlı mekânı, 1 fırın, 1 food market (toplam 27). Gastronomi planlama bandının altı hedef sayıya göre doldurulmadı; kapsam ve kaynak kalitesi esas alındı.
- Alışveriş matrisi 9 destinasyon adayını belgeliyor ve tüketicinin desteklediği tür/facet değerlerini kullanıyor; yeni `shoppingMall` veya `outlet` enum'u yok.
- Eser kapsamı: 6 müze, 45 eser; kullanıcı onaylı İstanbul Modern kapsam istisnası geçerli. Şehir geneli 60 eser sınırının altında.
- Kullanıcı onaylı 6 eser kapsanan müze / 5 deep / 1 selective politikası korundu.

## Root görünürlüğü — v13 kullanıcı talimatı uygulandı

Kullanıcı talimatıyla v12'de root dışında kalan 22 mevcut, koordinatlı ve üst seviye içerik `city.rootContentNodeIDs` listesine eklendi. Root sayısı 82'den 104'e çıktı; bu değişiklikle `ROOT_POI_NOT_LISTED` uyarıları 22'den 0'a düştü. Canonical ID'ler korunmuş, node içeriği değiştirilmemiştir.

Harita davranışı ayrı bir sözleşmedir: sağlanan `LeylekMapView.swift` içindeki `mapPOIs(for:)`, `repository.allNodes(for:)` çağırır ve koordinatı olan, `isMapPOI` tarafından desteklenen türdeki düğümleri alır. Root üyeliğine göre filtreleme yapmaz. Dolayısıyla bu 22 içerik, root'a eklenmeden önce de mevcut paket yüklüyken ve harita filtreleri dışlamıyorken harita işaretçisi olmaya uygundu. Root eklemesi, root tabanlı keşif/Explore görünürlüğünü etkiler; harita işaretçisi uygunluğunu değil.

## Kalan uyarılar

Pack-flow sonucu **0 hata, 54 uyarı**:

- **54 placeholder görsel uyarısı:** Mevcut node'lar `media/images/placeholder.png` kullanıyor. Görsel çalışması bu root-görünürlüğü güncellemesinde yapılmadı.

Görsel attribution registries: Wikimedia Commons için 189, Openverse için 8 mevcut görsel kaydı bulunuyor. Her ikisinde `packVersion=13`. Üç Openverse kaydı, yerel dosyaları bulunmadığı için kaynak kayıtlarından çıkarıldı. Bir genel `placeholder.png` dosyasının kendi kaynak kaydı yok; 54 referansın uyarısı korunuyor.

## Downstream handoff

- Temiz ZIP'e çalışma scripti ve envanter dahil edilmedi.
- Kaynak/attribution kayıtları, lisans açıklaması ve güncel final QA raporu korundu.
- `manifest.json` temiz staging'deki 228 dosyayı tanımlıyor; kendisini manifest girdisi olarak hash'lemiyor.
- No-upload publisher yolu kullanıldı; GitHub, katalog, audio generator ve image optimizer çalıştırılmadı. `InstalledPackContentRepository` per-city hata izolasyonu enjekte fake data source ile test edildi; gerçek disk/`CityPackStore` entegrasyonu test edilmedi.
- İçerik handoff sonucu üretim yayını, audio hazır olma durumu, Xcode derlemesi veya gerçek cihaz onayı değildir.

## Checkpoint

- `CITY_ID`: `istanbul`
- `PACK_VERSION`: `13`
- `SCHEMA_VERSION`: `4`
- `CURRENT_PHASE`: `Post-PHASE 8 root visibility update — COMPLETE`
- `REGISTRY_STATUS`: `FROZEN — canonical ID'ler korundu`
- `NODE_COUNT`: `200`
- `RELATION_COUNT`: `130`
- `ROOT_COUNT`: `104`
- `MUSEUM_COUNT`: `19`
- `ARTWORK_COUNT`: `45`
- `VALIDATION_GATE_RESULT`: `PASS WITH WARNINGS`
- `NEXT_ALLOWED_STEP`: downstream `leylek_pack_flow` audio/post-audio/publish adımlarını ayrı onayla çalıştırmak.


## v13 root görünürlüğü düzeltme kaydı

- Önceki paket: v12 / schema v4; root ID sayısı 82.
- Güncel paket: v13 / schema v4; root ID sayısı 104.
- Kullanıcı talimatıyla eklenen üst seviye node sayısı: 22; eksik veya yeni canonical ID oluşturulmadı.
- 22 node'un tümü önceden mevcut, `parentID: null`, koordinatlı ve mevcut Swift harita kodundaki `isMapPOI` filtresinin desteklediği türlerde.
- Bu revizyonda medya baytları ve audio alan değerleri değiştirilmedi.
